# Wine Reference: Migration 002 review package (2026-11-08)

Release `002 r1 (2026-11-08)`. **Implemented and tested locally; NOT run on production.** The app code (the Owner page's Reference tab)
is published, and shows "needs migration 002" until the owner runs it.

Start with `migration_002/README.md` (scope and design), then `migration_002/DEPLOY_002.md` (SQL Editor steps). The results are in
`results/`. The app changes are in `app/` (`data.js`, `owner.js`, the `app.js` diff, and every change since 001). `MANIFEST.txt` lists
the SHA-256 of every file.

Repository `ichiba1989/Wine-app-web`:
- `main` at 8e81e86;
- `vwm` at bb4f896.
