# Other results (2026-11-08)

- Venue app (`vwm`), after the merge: Migration 002 browser test 19 passed, 0 failed. Venue checks: venue_ui 17/0, sure_ui 14/0,
  vrev_ui 48/0.
- Found and fixed during the vwm merge: the import resolver left `rankAppellationFor` imported twice in `owner.js`, and the Owner page
  would not load on vwm. `node --check` does not catch this. The duplicate was removed and the merge recipe gained a module-parse step.
  Before the fix, venue_ui was 11/1; after it, 17/0.
- Main app regression, fake database: Pairings 11, More/Food 25, Atlas 39, restaurant 29, card map 19, Morgon 13, Grand Cru 8, label
  names 7, steps 12; foods_check 49, restaurant_check 38. All passed.
- Production, the app's public key only:
  - live_post_deploy_002.mjs: "Migration 002 is not deployed yet", as expected; it writes nothing;
  - live_smoke.mjs: 26/0;
  - live_ui.mjs: 26/0. This was the newly published code (main and /vwm/) against the production database.
- The website was republished automatically on push (pages.yml, run 134, success). For the Owner, the Reference tab says "needs
  migration 002" until it is run. Players see no change.
