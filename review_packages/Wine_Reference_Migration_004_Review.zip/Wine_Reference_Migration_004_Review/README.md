# Wine Reference: Migration 004 review package (2026-11-13)

Release `004 r1 (2026-11-13)`. **Implemented and tested locally; NOT run on production.** It needs 003 r1 deployed first.

Start with `migration_004/README.md` (what you can do, and the appellation_grape_rules decision), then `migration_004/DEPLOY_004.md`.
The results are in `results/`. `MANIFEST.txt` lists the SHA-256 of every file.

Repository `ichiba1989/Wine-app-web`:
- `main` at b7f42c1;
- `vwm` at 94da41f.
