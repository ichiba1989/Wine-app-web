# Other results (2026-11-13)

- Venue app (`vwm`) after the merge: the Migration 004 suite on the venue app passed 78/0. Venue checks: venue_ui 17/0, sure_ui 14/0,
  vrev_ui 48/0.
- Main app regression (fake database), all passed: Pairings 11, More/Food 25, Atlas 39, restaurant 29, card map 19, Morgon 13,
  Grand Cru 8, label names 7, steps 12; foods_check 49; restaurant_check 38.
- `live_post_deploy_004.mjs` against the local deployment: 21/0.
- Production, public key only, after publishing the new app code (production still has 002; 003 approved, not yet run):
  - `live_smoke.mjs` 26/0;
  - `live_ui.mjs` 26/0 (main and /vwm/);
  - `live_post_deploy_003.mjs` and `live_post_deploy_004.mjs`: "not deployed yet".
- The `vwm` merge needed one alignment: `owner.js` imports the venue's `aocgrapes.js?v=3`. The version check caught it.
