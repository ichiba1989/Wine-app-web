# Review manifest: Wine Education Master Reference, Phase 2.0B.3 final corrections (Migration 001 release r4)

| Item | Value |
|---|---|
| Repository | `ichiba1989/Wine-app-web` |
| Source branch | `main` |
| Source commit | `1f259ca3f1e5c29ab150c6220a14e01efd4da202` (files read from this commit) |
| Migration release | `001 r4 (2026-11-01)` (previous review package: r3 from `9fd5081`) |
| Venue branch | `vwm` at `825f0de` (same documents, merged) |
| Packaged | 2026-11-01 |
| Package | `Wine_Reference_Phase_2_0B_3_Security_Review.zip` (replaces the r3 package) |

## What changed since the r3 package

1. `ref_published_names` returns only names valid today (started, not ended); `has_display_name` checks the start date too.
2. A transaction-level editorial lock (`wine_reference.editorial_lock()`) taken first by `ref_review` and by every trigger that checks
   other rows; the private-copy check takes a shared row lock on its rights statement. Closes 11 races reproduced on r3.
3. New: `tests/concurrency_tests.sh`, `tests/concurrency_fixture.sql`, `STAGING_ASSESSMENT.md`; name-validity regression tests.
Read: `CHANGE_REPORT_2_0B_3.md` (final section), `DESIGN.md` 4c, then the SQL.

## Files and SHA-256 checksums

Repository files are unchanged copies of the commit above (checked byte for byte against git). `review_notes/` was written for this
package. This manifest is not in its own list.

| File | SHA-256 | What it is |
|---|---|---|
| `access.js` | `54c02a1226f2939399c868eb883e9bcea3dad8ff770a49d20b0d1769ba7e3bc1` | App-level permission code (UI gating only) |
| `docs/REFERENCE_MODEL.md` | `5cb5eafedb271023a899e1ce580ba71b811d70c41d84eaaf557f2da86fc55861` | Reference model (principles, open questions) |
| `docs/ROLES_AND_ACCESS.md` | `8230575c36f869e3c3147d22db1084ab501cc6f854cb80bfd3c1bbc870253e80` | Accounts, plans, roles and permissions |
| `docs/import_limit.sql` | `9675eae9a31a2e0225a772b7f72af553464dd51feacc4dc33dd0bea9e06d01ca` | Defines cfg_number(), used by the migration |
| `docs/reference/INSPECTION.md` | `15df0b76942b9a996239aca86739ffaaf183a374339dc51aa669c8ed1f87c032` | How the inspection was run |
| `docs/reference/WINE_REFERENCE_BRIEFING.md` | `c44c1d0604e72703f0d92684100f91c81b7321f894ed69424ad6f1aef02142c0` | One-document briefing of the whole effort |
| `docs/reference/inspect_1_structure.sql` | `c3c5e582caf451247768cea3eb1d2ee80e5a3b4e4bc3f8678e340686e3cce433` | Read-only inspection, structure |
| `docs/reference/inspect_2_catalog.sql` | `c3e8331876dbb80cf7ea5a00de741294bfed5855f4a07c8f7cadee3f6bbad26d` | Read-only inspection, catalog |
| `docs/reference/migration_001/001_rollback.sql` | `af80fc11000f6fc1279c8239e7491a8c017d1d3755489d42925d44cb22f096d7` | Rollback of 001 while empty; refuses until 001a is rolled back |
| `docs/reference/migration_001/001_verify.sql` | `3951eeb9bc39b18db2c938bce0826cfe3432a0f1fdf3e2973876a50822787689` | Read-only post-migration checks: grants, release, drift, health, 001a consistency |
| `docs/reference/migration_001/001_wine_reference_foundation.sql` | `4493d49c5db0cd7149eb717df425fa7f82ce808d0f1288d1b9d2a6a21349dafa` | Migration 001, release "001 r4 (2026-11-01)" (draft; not run live) |
| `docs/reference/migration_001/001a_reference_permissions.sql` | `0a5878c04707e084fda1b83cce636d21fc0635d9319794a573d8d2bedfe549d0` | Migration 001a: ref_* permissions for the Owner role; preflight (needs 001 r4) and postcondition |
| `docs/reference/migration_001/001a_rollback.sql` | `cc997dca39ac806c2bb121b76a5c5c13979a7318d08a3425cd1e8baecd397a18` | Rollback of 001a: removes the four ref_* permissions from every role |
| `docs/reference/migration_001/CHANGE_REPORT_2_0B_3.md` | `a74c41314c864900d34152dcc7f7a8a15ea9a24ac3fe14bcd580ac5bffbe81e0` | Phase 2.0B.3 corrections and the 2026-11-01 final follow-up; remaining risks |
| `docs/reference/migration_001/DATA_DICTIONARY.md` | `75310d1245037933a63c1a8cabad80b540685f460f0e9f88f9bc4f58cd99eea4` | Physical schema (generated from a tested r4 install) |
| `docs/reference/migration_001/DESIGN.md` | `63f2a31b1b724acd614e5c3e0236ec8671f34018fbbd0e9bcb17dfb6237f4d82` | Design; security 4, 4b, 4c (locking strategy); recovery; owner decisions; live checklist with fingerprints |
| `docs/reference/migration_001/OWNER_ROLE_VERIFICATION.md` | `f5b18d1b40a2aa67f61e269d8660f33d9bd112cd2091004752cd7b75dfd816af` | What the Owner check must confirm; what stays unverified |
| `docs/reference/migration_001/STAGING_ASSESSMENT.md` | `6b8706e8773a5b49a8fcf333d7fe303b4f84c858c848a86ac92c4cd9d43d4ae5` | Disposable Supabase staging options without production credentials (not done) |
| `docs/reference/migration_001/TEST_REPORT.md` | `ed6affb1c7f14e9c7f686dc392db37c190452b85f79804875d2c53ff44d55222` | Local test report: 294 passed, 0 failed; concurrency method and r3-vs-r4 table |
| `docs/reference/migration_001/owner_role_check.sql` | `e911b62ebfba298b516263f77780bc7698acecbd63b974da1f3ba379dbf8fad4` | Read-only check of the live Owner lookup and profile protections (for the owner to run) |
| `docs/reference/migration_001/tests/001_behaviour_tests.sql` | `b0ee7dc55fd2140adf98f758ead989bd15be004f7a516bb5d4a156a8639fd6a6` | Behaviour, negative, lifecycle and name-validity tests (local only; writes test rows) |
| `docs/reference/migration_001/tests/concurrency_fixture.sql` | `b976378fd733fc3983cd7e64148f8612056322ef68b781f1b315171ad209ab1c` | Fixture for the concurrency checks (local only) |
| `docs/reference/migration_001/tests/concurrency_tests.sh` | `58bb68d656e12e82d2949492f727c44977645b44101aecbd61e6a15da80a5bc2` | Two-session concurrency checks C1a..C10 (local only) |
| `docs/reference/migration_001/tests/dictionary.sql` | `be8594183e5cd08a8c7ed69fc2cd443d65c881964c20a7c9cd981fd47d019155` | Read-only generator for DATA_DICTIONARY.md |
| `docs/reference/migration_001/tests/run_local_tests.sh` | `dd7edcd47e5b346515b4a33c2ca3fd9d774119f6aea6966754cf34e5b6d91a69` | Test runner (includes the concurrency checks) |
| `docs/reference/migration_001/tests/stub_supabase.sql` | `75a5051e2c001f08d9564f38c3f9770b214f20934eb1f1f66fe1db2bedf8dee3` | Local stand-ins for Supabase objects (local only) |
| `docs/reference/results/FINDINGS.md` | `212a14c582d96c1ab46db014ece409c852944d1bda97bcc3388d499614f4e5a5` | Summary of the live read-only inspection (2026-10-26) |
| `docs/roles_discovery_two.sql` | `b678083bfdb5fc62dde7ee315eb8989c0a5121da3891aae0d8aa6e96db716f14` | Read-only script that read the role lookup on 2026-10-14 (result not saved) |
| `docs/roles_proposal.sql` | `4b58cc7e0b413abbff82af5d1baa0c47d70e9a7fa6e82bc62cfa3137755b8f49` | Staff role functions (Owner lock; inline role rule) |
| `review_notes/LOCAL_TEST_RUN_AT_PACKAGING.txt` | `98068830c85246363e2699f118d1dde8b344fbe23a1ae6cfaa741e99abc1f6e5` | Written for this package: full test output, re-run at packaging on a clean checkout |
| `review_notes/R3_SAME_SUITE_FOR_COMPARISON.txt` | `49320665d099cc0f1e10b5563fd98005833687dc85e2905c6f0bb9bb93b2af47` | Written for this package: the same suite on the unchanged r3 SQL (16 expected failures) |

Total: 31 files listed above, plus this manifest = 32 files in the ZIP.

SQL fingerprints (first 16 hex; match DESIGN.md section 8): foundation `4493d49c5db0cd71`, 001a `0a5878c04707e084`, verify
`3951eeb9bc39b18d`, 001 rollback `af80fc11000f6fc1`, 001a rollback `cc997dca39ac806c`, owner check `e911b62ebfba298b`.

## Test results

- **Newly executed while packaging (2026-11-01):** full suite on a clean checkout of `1f259ca3f1e5c29ab150c6220a14e01efd4da202`, throwaway local PostgreSQL 16.15:
  **294 passed, 0 failed**, including 13 concurrency checks. Output: `review_notes/LOCAL_TEST_RUN_AT_PACKAGING.txt`.
- **Comparison, newly executed (2026-11-01):** the same suite against the unchanged r3 SQL: **278 passed, 16 failed** (5 name-validity
  checks, 11 concurrency races). Output: `review_notes/R3_SAME_SUITE_FOR_COMPARISON.txt`.
- **Previously reported:** r3 270 passed, 0 failed (2026-10-27); 160 (Owner override); 127 (first draft).
- **Concurrency method:** two real sessions per scenario on a fresh fixture copy; session 1 decides and holds its transaction 1.5 s;
  session 2 starts 0.4 s later; READ COMMITTED. On r4 session 2 waited about 1.1 s each time, then completed safely or was refused.
- All local against stand-ins; never against Supabase.

## Outstanding risks and limitations

1. Live `my_staff_role_code()`, `has_permission()`, `auth.uid()` definitions are not in the repository; the Owner override trusts
   `my_staff_role_code()`. Unverified until the owner runs `owner_role_check.sql` (OWNER_ROLE_VERIFICATION.md).
2. `anon` holds table-level UPDATE on `profiles` (Supabase default; the row policy `id = auth.uid()` blocks it); players' column
   grants were not read by the inspection.
3. Not tested on Supabase (superuser model, event triggers, Exposed schemas, PostgREST with real tokens). Possible without production
   credentials (STAGING_ASSESSMENT.md); needs owner approval.
4. Editorial decisions are serialised by one lock: a long editorial transaction makes others wait; the advisory-lock key
   `(20261101, 1)` must stay unique in the database; concurrency tested with two sessions, not under load.
5. Soundness and suspension scan every published version on each retire or publish; real volumes untested.
6. Names can end by date: the entity is hidden (fail closed) and listed by verify, not prevented in advance.
7. Suspension is final for a version (owner to confirm).
8. A private source copy whose rights are retired later is listed by verify; the file is not removed by the database.
9. Missing: the 14 approved domains, the ~140-subdomain taxonomy, the Phase 1.9 document (taxonomy tables empty). Raw live
   inspection output is kept by the owner.

## Security screening

No `.env`, keys, tokens, JWTs, Supabase keys, passwords, connection strings, emails, private user data (made-up test ids only),
raw production exports or licensed documents. No sanitizing needed; no redactions.

## Confirmation

No live database change, no migration run, no connection to Supabase, no hosted project created, no application code change, no
permission change.
