# Review manifest: Wine Education Master Reference, Phase 2.0B.3 r3 (Migration 001 security review package)

| Item | Value |
|---|---|
| Repository | `ichiba1989/Wine-app-web` |
| Source branch | `main` |
| Source commit | `9fd508193d551ef08c239c1acfe476f4a8c59a61` (files were read from this commit, not from a working folder) |
| Migration release | `001 r3 (2026-10-27)` |
| Venue branch | `vwm` at `552a9d9`, contains the same documents (merge of main) |
| Packaged | 2026-11-01 |
| Package | `Wine_Reference_Phase_2_0B_3_Security_Review.zip` (replaces the 2026-10-26 package built from `e59ed94`, the 160-test version) |

## Purpose

Independent final SQL, architecture and security review of Migration 001 release r3 (a private schema `wine_reference` plus two
functions in `public`). **Read in this order:** `docs/reference/migration_001/CHANGE_REPORT_2_0B_3.md`, `DESIGN.md` (sections 4, 4b, 6, 8),
`001_wine_reference_foundation.sql`, `001a_reference_permissions.sql`, the two rollbacks, `001_verify.sql`, `OWNER_ROLE_VERIFICATION.md`
and `owner_role_check.sql`, then the tests.

## Files and SHA-256 checksums

Every repository file is an unchanged copy of the commit above (checked byte for byte against git). `review_notes/` was written for this
package. This manifest is not in its own list.

| File | SHA-256 | What it is |
|---|---|---|
| `access.js` | `54c02a1226f2939399c868eb883e9bcea3dad8ff770a49d20b0d1769ba7e3bc1` | App-level permission code (UI gating only) |
| `docs/REFERENCE_MODEL.md` | `5cb5eafedb271023a899e1ce580ba71b811d70c41d84eaaf557f2da86fc55861` | Reference model (principles, open questions) |
| `docs/ROLES_AND_ACCESS.md` | `8230575c36f869e3c3147d22db1084ab501cc6f854cb80bfd3c1bbc870253e80` | Accounts, plans, roles and permissions |
| `docs/import_limit.sql` | `9675eae9a31a2e0225a772b7f72af553464dd51feacc4dc33dd0bea9e06d01ca` | Defines cfg_number(), used by the migration |
| `docs/reference/INSPECTION.md` | `15df0b76942b9a996239aca86739ffaaf183a374339dc51aa669c8ed1f87c032` | How the inspection was run |
| `docs/reference/WINE_REFERENCE_BRIEFING.md` | `ae379b76549dc71488e89e8978167f6ba59fa84b3a4fbae7a04f47e65a2ed28d` | One-document briefing of the whole effort |
| `docs/reference/inspect_1_structure.sql` | `c3c5e582caf451247768cea3eb1d2ee80e5a3b4e4bc3f8678e340686e3cce433` | Read-only inspection, structure |
| `docs/reference/inspect_2_catalog.sql` | `c3e8331876dbb80cf7ea5a00de741294bfed5855f4a07c8f7cadee3f6bbad26d` | Read-only inspection, catalog |
| `docs/reference/migration_001/001_rollback.sql` | `af80fc11000f6fc1279c8239e7491a8c017d1d3755489d42925d44cb22f096d7` | Rollback of 001 while empty; refuses until 001a is rolled back |
| `docs/reference/migration_001/001_verify.sql` | `ff1a93575ca6756afe0f23b38b67904c70e69ba71adc609ddcd978448ae3e646` | Read-only post-migration checks: grants, release, drift, health, 001a consistency |
| `docs/reference/migration_001/001_wine_reference_foundation.sql` | `11c72574bccd582778290e71b52801d365a15f645a9966515f8b3beb51e18d30` | Migration 001, release "001 r3 (2026-10-27)" (draft; not run live) |
| `docs/reference/migration_001/001a_reference_permissions.sql` | `c9232eb17045188851d53aff591769c7fe9715ca92bc90cb3a63d84aa89d467a` | Migration 001a: ref_* permissions for the Owner role (separate approval); preflight and postcondition |
| `docs/reference/migration_001/001a_rollback.sql` | `cc997dca39ac806c2bb121b76a5c5c13979a7318d08a3425cd1e8baecd397a18` | Rollback of 001a: removes the four ref_* permissions from every role |
| `docs/reference/migration_001/CHANGE_REPORT_2_0B_3.md` | `c9348841cf2b10fc14187bb5e051347ab8e59428f17fde2a5b8b632a797bff33` | Phase 2.0B.3 corrections, bugs found, unresolved risks |
| `docs/reference/migration_001/DATA_DICTIONARY.md` | `0b21d14433716e1f238294bcf7a7462d144defcd60ce21ecc7b670def3ff5620` | Physical schema (generated from a tested install) |
| `docs/reference/migration_001/DESIGN.md` | `76d0d4917f5cbdbdf70ee4fc208cc211cbf0bc1a9e69dcbbbef6618d8a344ff5` | Design, security review (4, 4b), compatibility, recovery, owner decisions, live checklist with fingerprints |
| `docs/reference/migration_001/OWNER_ROLE_VERIFICATION.md` | `f5b18d1b40a2aa67f61e269d8660f33d9bd112cd2091004752cd7b75dfd816af` | What the Owner check must confirm; what stays unverified |
| `docs/reference/migration_001/TEST_REPORT.md` | `3c5979fa2c379299c6ce762942b25946680b1cc827e1dcb6027538200573d2e8` | Local test report: 270 passed, 0 failed (as committed) |
| `docs/reference/migration_001/owner_role_check.sql` | `e911b62ebfba298b516263f77780bc7698acecbd63b974da1f3ba379dbf8fad4` | Read-only check of the live Owner lookup and profile protections (for the owner to run) |
| `docs/reference/migration_001/tests/001_behaviour_tests.sql` | `1fde80dfd95a4ee774f183eb349c117e4935fa7c75a44ac7e2c418180a00cf7b` | Behaviour, negative and lifecycle tests (local only; writes test rows) |
| `docs/reference/migration_001/tests/dictionary.sql` | `be8594183e5cd08a8c7ed69fc2cd443d65c881964c20a7c9cd981fd47d019155` | Read-only generator for DATA_DICTIONARY.md |
| `docs/reference/migration_001/tests/run_local_tests.sh` | `5d4e17b30af6107d3c8a092a52f69932b775e69f7a11122320ec0fbb8af41d6e` | Test runner: install, replay, compatibility, verify, behaviour, preflight, rollback |
| `docs/reference/migration_001/tests/stub_supabase.sql` | `75a5051e2c001f08d9564f38c3f9770b214f20934eb1f1f66fe1db2bedf8dee3` | Local stand-ins for Supabase objects (local only) |
| `docs/reference/results/FINDINGS.md` | `212a14c582d96c1ab46db014ece409c852944d1bda97bcc3388d499614f4e5a5` | Summary of the live read-only inspection (2026-10-26) |
| `docs/roles_discovery_two.sql` | `b678083bfdb5fc62dde7ee315eb8989c0a5121da3891aae0d8aa6e96db716f14` | Read-only script that read the role lookup on 2026-10-14 (result not saved) |
| `docs/roles_proposal.sql` | `4b58cc7e0b413abbff82af5d1baa0c47d70e9a7fa6e82bc62cfa3137755b8f49` | Staff role functions (Owner lock; inline role rule) |
| `review_notes/LOCAL_TEST_RUN_AT_PACKAGING.txt` | `f2b081dffe5434324f6e6337534b03448e3af0548d68820b1f30402fa9eb8079` | Written for this package: full test output, re-run at packaging |

Total: 27 files listed above, plus this manifest = 28 files in the ZIP.

## This is the r3 SQL, not the earlier 160-test version

- `001_wine_reference_foundation.sql` starts with release "001 r3" and contains the r3 objects (`version_problems`, `is_current`,
  `suspend_unsound`, `structure_fingerprint`, `guard_row`, `has_display_name`, the 0b preflight, `ref_review` with a fifth argument).
- First 16 hex of each SQL file's SHA-256 match the deployment checklist in `DESIGN.md` section 8: foundation `11c72574bccd5827`,
  001a `c9232eb170451888`, verify `ff1a93575ca6756a`, 001 rollback `af80fc11000f6fc1`, 001a rollback `cc997dca39ac806c`,
  owner check `e911b62ebfba298b`. (The earlier package had foundation `ae69fb54...` and no 001a rollback or owner check.)

## Test results

- **Newly executed while packaging (2026-11-01):** the full suite on a clean checkout of commit `9fd5081`, throwaway local PostgreSQL
  16.15: **270 passed, 0 failed** (PASS lines = total). Output: `review_notes/LOCAL_TEST_RUN_AT_PACKAGING.txt`.
- **Previously reported:** 270 passed, 0 failed (`TEST_REPORT.md`, 2026-10-27). Earlier history: 127 (first draft), 160 (Owner override).
- All local, against stand-ins (`tests/stub_supabase.sql`); never against Supabase.

## Outstanding risks and limitations

1. `public.my_staff_role_code()`, `has_permission()` and `auth.uid()` live definitions are not in the repository; the Owner override
   trusts `my_staff_role_code()`. Unverified until the owner runs `owner_role_check.sql` and confirms `OWNER_ROLE_VERIFICATION.md`.
2. Live inspection showed signed-out `anon` holds table-level UPDATE on `profiles` (Supabase default; the row policy `id = auth.uid()`
   blocks it) and signed-in players are said to be limited by column-level grants that the inspection did not read.
3. Not tested on Supabase itself (superuser model, event triggers, the Exposed schemas setting).
4. Soundness and suspension scan every published version on each retire or publish; concurrency and real volumes untested.
5. Names can end by date (`valid_to`): the entity is then hidden (fail closed) and listed by verify, not prevented in advance.
6. Suspension is final for a version (by design; owner to confirm).
7. A private source copy whose rights are retired later is listed by verify; the stored file is not removed by the database.
8. Missing from the repository: the 14 approved knowledge domains, the ~140-subdomain taxonomy, the Phase 1.9 document (taxonomy tables
   are created empty). The raw live inspection output is kept by the owner and not included.
9. Not included on purpose: `config.js` (project URL and public key) and other application files.

## Security screening of this package

No `.env` files, API keys, tokens, JWTs, Supabase keys, passwords, connection strings, email addresses, private user data (only made-up
test ids), raw production exports or licensed documents. **No file needed sanitizing; no redactions.**

## Confirmation

No live database change, no migration run, no connection to Supabase, no application or migration SQL change, no permission change.
