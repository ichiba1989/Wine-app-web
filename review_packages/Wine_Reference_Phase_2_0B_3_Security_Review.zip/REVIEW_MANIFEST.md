# Review manifest: Wine Education Master Reference, Phase 2.0B.3 (Migration 001 security review package)

| Item | Value |
|---|---|
| Repository | `ichiba1989/Wine-app-web` |
| Branch | `main` |
| Commit | `e59ed94176588791d3791da35c93e08edb89676f` (working tree clean; identical to `origin/main` at packaging) |
| Packaged | 2026-10-26 |
| Package | `Wine_Reference_Phase_2_0B_3_Security_Review.zip`, repository folder structure preserved |

## Purpose

Everything needed for an independent final SQL, architecture and security review of Migration 001 (a new private schema
`wine_reference` plus two functions in `public`). **Start with** `docs/reference/migration_001/DESIGN.md`, then the SQL, then
`review_notes/OWNER_ROLE_VERIFICATION.md`.

## Files and SHA-256 checksums

Files from the repository are unchanged copies of the commit above. Files under `review_notes/` were written for this package.
This manifest is not in its own list (a file cannot hold its own checksum).

| File | SHA-256 | What it is |
|---|---|---|
| `access.js` | `54c02a1226f2939399c868eb883e9bcea3dad8ff770a49d20b0d1769ba7e3bc1` | App-level permission code (UI gating only) |
| `docs/REFERENCE_MODEL.md` | `54c7d1f97b0ce6cd2f7c60a64f0969906c9c3abb74658cd8ff2615973490a0ec` | Reference model (principles, open questions) |
| `docs/ROLES_AND_ACCESS.md` | `8230575c36f869e3c3147d22db1084ab501cc6f854cb80bfd3c1bbc870253e80` | Definition of accounts, plans, roles and permissions |
| `docs/import_limit.sql` | `9675eae9a31a2e0225a772b7f72af553464dd51feacc4dc33dd0bea9e06d01ca` | Defines cfg_number(), used by the migration |
| `docs/reference/INSPECTION.md` | `15df0b76942b9a996239aca86739ffaaf183a374339dc51aa669c8ed1f87c032` | How the inspection was run |
| `docs/reference/WINE_REFERENCE_BRIEFING.md` | `af459f8a6800ae46f0b1acbb848ca9a91145fd6591526d97acf5fe8d609674b3` | One-document briefing of the whole effort |
| `docs/reference/inspect_1_structure.sql` | `c3c5e582caf451247768cea3eb1d2ee80e5a3b4e4bc3f8678e340686e3cce433` | Read-only inspection, structure |
| `docs/reference/inspect_2_catalog.sql` | `c3e8331876dbb80cf7ea5a00de741294bfed5855f4a07c8f7cadee3f6bbad26d` | Read-only inspection, catalog |
| `docs/reference/migration_001/001_rollback.sql` | `210b650d5b103a2f9c1e922573ad2e30c0a7e3fd5e662ba7dc4a294c927a2702` | Rollback while the reference is empty |
| `docs/reference/migration_001/001_verify.sql` | `512247ba1d83ae50be688287642c481d7c4b3c0accb4ab7f840095b07cc307bf` | Read-only post-migration checks |
| `docs/reference/migration_001/001_wine_reference_foundation.sql` | `ae69fb54f1be71d7c264acaaef9ed476cf5a01d4027b74465618289849aad954` | Migration 001 (draft, not run live) |
| `docs/reference/migration_001/001a_reference_permissions.sql` | `8cf791d1e3d0256ad1129794a89aac324d20462bc92265b0f7a6955c4c7bd1b9` | Migration 001a: ref_* permissions for the Owner role (separate approval) |
| `docs/reference/migration_001/DATA_DICTIONARY.md` | `80c0fe1957371118b65602dd146857b87dc934081719dce4fd8199ef3e2db719` | Physical schema (generated from a tested install) |
| `docs/reference/migration_001/DESIGN.md` | `526e93097cceb1857dcdd90196d6c6bab35a537ba0adcfd68561d94a9f819454` | Design, security review, compatibility, recovery, owner decisions, live checklist |
| `docs/reference/migration_001/TEST_REPORT.md` | `a61d696ab4faa29d70bbe219ee813090d2614d81772d42ba2e04a1c28d953d5d` | Local test report (160 passed) |
| `docs/reference/migration_001/tests/001_behaviour_tests.sql` | `03b4aa91744ae275fddb7fee2426e78b2282055833042558da5cc4467a88c0fc` | Behaviour and negative tests (local only; writes test rows) |
| `docs/reference/migration_001/tests/dictionary.sql` | `be8594183e5cd08a8c7ed69fc2cd443d65c881964c20a7c9cd981fd47d019155` | Read-only generator for DATA_DICTIONARY.md |
| `docs/reference/migration_001/tests/run_local_tests.sh` | `8e3a657e8623d94410af9f77831dc32e18ddb7261a33efc249dbc3b9cf287c79` | Test runner (throwaway local PostgreSQL) |
| `docs/reference/migration_001/tests/stub_supabase.sql` | `75a5051e2c001f08d9564f38c3f9770b214f20934eb1f1f66fe1db2bedf8dee3` | Local stand-in for Supabase objects (local only) |
| `docs/reference/results/FINDINGS.md` | `212a14c582d96c1ab46db014ece409c852944d1bda97bcc3388d499614f4e5a5` | Summary of the live read-only inspection |
| `docs/roles_discovery_two.sql` | `b678083bfdb5fc62dde7ee315eb8989c0a5121da3891aae0d8aa6e96db716f14` | Read-only script that read my_staff_role_code() on 2026-10-14 (result not saved) |
| `docs/roles_proposal.sql` | `4b58cc7e0b413abbff82af5d1baa0c47d70e9a7fa6e82bc62cfa3137755b8f49` | Staff role functions (owner lock; inline role rule) |
| `review_notes/LOCAL_TEST_RUN_AT_PACKAGING.txt` | `c1f6fe337be76285f7ac4179acc566202bfdcd0478de9dd68cb54824dc48e883` | Written for this package: test output re-run at packaging |
| `review_notes/OWNER_ROLE_VERIFICATION.md` | `edcba58c309a27e938d6b072316b9afbdf0d25c791bbb91cdeec4678e3a35ca4` | Written for this package: Owner lookup assumptions and gaps |

Total: 24 files listed above, plus this manifest = 25 files in the ZIP.

## Local test result

- **Previously reported** (TEST_REPORT.md): 160 passed, 0 failed.
- **Independently re-run while packaging**, at the commit above, with `docs/reference/migration_001/tests/run_local_tests.sh` on a
  throwaway local PostgreSQL 16.15: **160 passed, 0 failed**. Full output: `review_notes/LOCAL_TEST_RUN_AT_PACKAGING.txt`.
- These are local tests against stand-ins (`tests/stub_supabase.sql`), not against Supabase.

## Known limitations and missing files

- **`public.my_staff_role_code()` definition: not in the repository** (created by hand in Supabase). See
  `review_notes/OWNER_ROLE_VERIFICATION.md`. The tests use a stand-in that follows the documented rule.
- **`public.has_permission(text)` and `auth.uid()` definitions: not in the repository**; stand-ins in the tests. Documented behaviour in
  `docs/ROLES_AND_ACCESS.md`.
- **The raw live inspection output is not included** (kept by the owner; the website publishes the repository's `docs/`). Its summary is
  `docs/reference/results/FINDINGS.md`.
- **The Phase 1.9 document, the 14 approved knowledge domains and the ~140-subdomain taxonomy do not exist in the repository**; the
  migration's taxonomy tables are created empty.
- Supabase-specific behaviour (event triggers, the dashboard's Exposed schemas setting, the `postgres` role not being a superuser) is not
  reproduced locally; `001_verify.sql` is meant to be run on the live database after the migration.
- Not included on purpose: `config.js` (holds the project URL and the public, row-level-security-protected key; not needed for the
  review) and every application file other than `access.js`.

## Security screening of this package

Checked before zipping: no `.env` files; no API keys, access tokens, JWTs, Supabase service-role or publishable keys, database passwords
or connection strings; no email addresses; no private user data (the only ids are made-up test ids); no raw production export; no
licensed source documents. **No file needed sanitizing; no redactions were made.**

## Confirmation

This packaging task made **no live database change** (no connection to Supabase was made), ran **no migration**, and **modified no
application or repository file**: files were copied out of the repository; the repository's working tree was clean before and after.
