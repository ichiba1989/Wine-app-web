# Owner role verification: public.my_staff_role_code()

Written for this review package on 2026-10-26. **The definition of `public.my_staff_role_code()` is NOT in the repository.** It was created
by hand in Supabase ("database update 13", per `docs/ROLES_AND_ACCESS.md`). No connection to the production database was made for this
package, and the live definition was not retrieved.

## What is known about it, and from where

| Fact | Source in this package |
|---|---|
| It exists on the live database in schema `public`, returns `text`, takes no arguments, is `SECURITY DEFINER`, `stable`, language `sql`, `search_path=public`, and is executable by PUBLIC, `anon`, `authenticated` and `service_role` | `docs/reference/results/FINDINGS.md` summarises the owner's read-only structure inspection of 2026-10-26 (section 07 of `inspect_1_structure.sql`); the raw output was kept by the owner and is not included |
| Documented rule: a person's role is `profiles.staff_role`, or for older accounts `profiles.role` = `admin` means Owner and `editor` means Editor | `docs/roles_proposal.sql` header (line 4) and `docs/ROLES_AND_ACCESS.md` ("Where the database part lives") |
| The same rule is written inline in the repository's own staff functions: `coalesce(case when role = 'admin' then 'owner' end, staff_role, case when role = 'editor' then 'editor' end)` | `docs/roles_proposal.sql` (`staff_list`, `staff_set_role`, `staff_remove`) |
| `has_permission()` and `my_staff_access()` find the person's role through `my_staff_role_code()` | `docs/ROLES_AND_ACCESS.md`; `docs/roles_discovery_two.sql` header |
| The Owner role cannot be granted or changed by the app's staff functions; it is set only by hand in SQL | `docs/roles_proposal.sql` (`staff_set_role` refuses roles other than editor / quiz_reviewer and refuses to touch an owner; `staff_remove` likewise); `docs/ROLES_AND_ACCESS.md` |
| Players cannot change `profiles.role` or `profiles.staff_role` | Live grants as inspected (raw output, summarised in FINDINGS part 1): `authenticated` (every signed-in player, guests included) has **no table-level UPDATE** on `profiles`; project notes say its update grant is column-level, covering only name and consent columns (column-level grants were not part of the inspection). `anon` (signed out) **does** hold table-level UPDATE on `profiles` (Supabase's default grant); the row-level policy `profiles_self_update` (`using id = auth.uid()`, no `with check`) is what blocks it, since a signed-out caller has no user id |
| `profiles.staff_role` references `staff_roles(code)`; `profiles.role` is enum `user_role` (`player, contributor, editor, admin`) | FINDINGS part 1 (constraints, enums) |
| The function body was read once on 2026-10-14 with `docs/roles_discovery_two.sql` (read-only); the result was not saved in the repository | `docs/roles_discovery_two.sql` |

## Where migration 001 calls it

- `docs/reference/migration_001/001_wine_reference_foundation.sql`, step 0: `to_regprocedure('public.my_staff_role_code()')` must exist, or the
  migration stops before changing anything.
- Same file, inside `public.ref_review(...)`, only on an `approve` decision where the actor is the author (or the author is unknown):
  `if coalesce(public.my_staff_role_code(), '') = 'owner' then v_override := true; else raise ...`. The result is recorded as
  `review_events.owner_override`.
- `docs/reference/migration_001/001_verify.sql`: checks the function exists.
- Tests: `tests/stub_supabase.sql` defines a **stand-in** with the documented rule; `tests/001_behaviour_tests.sql` (owner section) exercises it.

## What the migration assumes it returns

1. `'owner'` if and only if the **signed-in caller** (`auth.uid()`) has the Owner role (`profiles.staff_role = 'owner'`, or `profiles.role = 'admin'`).
2. Something other than `'owner'` (another role code, or `NULL`) for everyone else, including signed-out callers and users with no profile row.
3. It reads only server-side data (`profiles`) for `auth.uid()`; it does not read request headers, session settings, JWT claims other
   than the user id, or any value the caller can supply.
4. It is evaluated afresh on every call (no caching), so removing the Owner role takes effect on the next call.

## What cannot be verified without the live definition

- The exact body: whether it uses `auth.uid()` (and not, for example, a JWT `role` claim or `request.jwt.claims` fields a client could
  influence), and whether the precedence of `role = 'admin'` over `staff_role` matches the documented rule.
- Whether it can return `'owner'` for any path other than the two documented ones (for example a third legacy value, or a default).
- Its exact `search_path` handling inside the body (the inspection shows `search_path=public`; whether objects are schema-qualified is unknown).
- Whether any other role or function can set `profiles.staff_role = 'owner'` (the repository's staff functions cannot; other live
  functions or triggers not in the repository were not read; `protect_profile_columns` is named in `roles_discovery_two.sql` but its body
  is not in the repository).
- Column-level grants on `profiles` (not part of the inspection).
- That `profiles_self_update` (no `with check` clause) cannot be used by a signed-in user to change their own `role` or `staff_role`:
  this rests on the column-level grant described in the project notes, which the inspection did not read.

## Recommended check before any live run (read-only, done by the owner in the SQL Editor)

```sql
select pg_get_functiondef('public.my_staff_role_code()'::regprocedure);
select column_name, grantee, privilege_type from information_schema.column_privileges
 where table_schema = 'public' and table_name = 'profiles' and grantee in ('anon', 'authenticated') and privilege_type = 'UPDATE';
```

Confirm: the body returns `'owner'` only for the signed-in user's `staff_role = 'owner'` or `role = 'admin'`; and neither `role` nor
`staff_role` appears in the UPDATE column grants for `anon` or `authenticated`. This step is also in `DESIGN.md` section 8.
