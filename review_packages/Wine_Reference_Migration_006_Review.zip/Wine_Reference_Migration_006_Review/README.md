# Migration 006 review package (2026-11-25)

Release "006 r1 (2026-11-25)". It adds one READ-ONLY door, `public.ref_browse`, plus the Reference tab's Evidence review, Browse all
(with putting several things in a subject area) and Compare side by side.

- **Not run on production.** The app screens are on the unpublished branch `claude/wine-app-setup-35g1ne` and not on the live site.
- Read `migration_006/README.md`, then `migration_006/DEPLOY_006.md`.
- Results are in `results/`: the local suite 179/0, editorial 47/0, and the app checks in `OTHER_RESULTS.md`.
