# Other results (2026-11-25)

App regression, with the browser checks in `docs/tools` run at phone width against stubs:

| Branch | Checks |
|---|---|
| `main` (phase 006 commit) | atlas_ui 39/0, cardmap_ui 19/0, mortet_ui 7/0, morgon_ui 13/0, rank_ui 8/0, steps_ui 12/0, food_ui 4/0, food_more_ui 25/0, food_owner_ui 11/0, restaurant_ui 29/0, foods_check 49/0, restaurant_check 38/0 |
| `vwm`, rehearsed merge (not pushed) | atlas_v 14/0, cardmap_v 19/0, venue_ui 17/0, vrev_ui 48/0, sure_ui 14/0, steps_v 12/0, mortet 7/0, morgon 13/0, rank 8/0, food 4/0, food_more 25/0, food_owner 11/0, restaurant 29/0 |

Pure rules: editorial 13/0, 003 10/0, 004 6/0, 005 8/0, 006 37/0.

`live_post_deploy_006.mjs`: 35/0 against the local stack; against production it says "Migration 006 is not deployed yet".
