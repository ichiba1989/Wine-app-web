# Manifest: Wine Reference Migration 001 r5, final (release "001 r5 (2026-11-08)")

- Approved by the owner (decisions 5, 14, 15, 16) but NOT run on production. Run it with DEPLOY_001.md after the owner's explicit go-ahead.
- Commit on main: cf6ca69634cbb56ea1def595fd709d08715e3beb; merged into vwm: 18d6034b384be00884dbd0a7e66e5160cc84802d. sql/ is byte-identical to that commit.
- results/: local suite 359/0; local Supabase compat 341/0; hardened-DB suite 352/0; production order on a hardened DB (one test-quoting FAIL in that log, re-checked directly: Owner only holds ref_* = true / 0 other roles). No keys or tokens.

| SHA-256 | File |
|---|---|
| `84f986a48809c6a9a43f04da647c81614fb28af973ffcb5b0ede1232290e6c00` | `DEPLOY_001.md` |
| `9a077156f7658ef5df3cebef44f5281e59a1488569735693bd6f5ed91aed0624` | `live_post_deploy.mjs` |
| `3c8ae7c8d915cbdfe4bf5299095a4b1dad11a518d8fb91fe5691e781f24e2aa9` | `reports/CHANGE_REPORT_2_0B_5.md` |
| `a657b9c34b8fefd295c28022ba6c494f7567ccb158fceee0551dca47c0c704b7` | `reports/DATA_DICTIONARY.md` |
| `f0b3a5b7efeae7d3594819940458ed6c507c60e5d240996fa60b3888bb74bb60` | `reports/DESIGN.md` |
| `f5b18d1b40a2aa67f61e269d8660f33d9bd112cd2091004752cd7b75dfd816af` | `reports/OWNER_ROLE_VERIFICATION.md` |
| `d484cd3204776cfa493cfa6153bf09bf5037f3ea73023818be7e71257dccd8f9` | `reports/TEST_REPORT.md` |
| `14d39d343f86eda0e0a955ff9f35027d12256114309562dcc4f02750da4d09cb` | `results/hardened_db_suite.txt` |
| `f8ac8d1461406b5b096116e65f67fda1b18aa9bc709fb0aea74c5fb84434d034` | `results/local_suite.txt` |
| `b4f065b00009881af9310187f4b6e822d35ef0abe805675641f3d730e6026621` | `results/production_order_on_hardened_db.txt` |
| `471f53d31fe7cc7fa3bba96b6c588c45d58d985b1db149ac252f1049346c97c7` | `results/supabase_compat.txt` |
| `af80fc11000f6fc1279c8239e7491a8c017d1d3755489d42925d44cb22f096d7` | `sql/001_rollback.sql` |
| `35422d599935a784c5d297682369a179be2c4773fcc9798016b5a8789d57bdff` | `sql/001_verify.sql` |
| `363f4022eb2c0f6b305af1e0cd28a24738df76b93fadb55dfc2426de151e60dd` | `sql/001_wine_reference_foundation.sql` |
| `980a8a67df975a8698bee78695043ce1f7feeae31dc5e99db44774f8aa5a243e` | `sql/001a_reference_permissions.sql` |
| `cc997dca39ac806c2bb121b76a5c5c13979a7318d08a3425cd1e8baecd397a18` | `sql/001a_rollback.sql` |
| `e911b62ebfba298b516263f77780bc7698acecbd63b974da1f3ba379dbf8fad4` | `sql/owner_role_check.sql` |
| `b0ee7dc55fd2140adf98f758ead989bd15be004f7a516bb5d4a156a8639fd6a6` | `tests/001_behaviour_tests.sql` |
| `921ff8020405637f7542bcfec2a1a03de386c38b3ab8df36d51850a766432c0e` | `tests/001_r5_tests.sql` |
| `8728e2d4a16354c7ae647b3b05a160c6fe1367c6b08599f9364a3ce75f167989` | `tests/concurrency_fixture.sql` |
| `4bd63656d3dbbcb79113da10f2205fa034e06ccc7426dd1b090c18eab24b8647` | `tests/concurrency_tests.sh` |
| `be8594183e5cd08a8c7ed69fc2cd443d65c881964c20a7c9cd981fd47d019155` | `tests/dictionary.sql` |
| `6445c420fb9eabd98533c3a88180ffe200d74e7e244ffe7056891267ecdc3946` | `tests/run_local_tests.sh` |
| `75a5051e2c001f08d9564f38c3f9770b214f20934eb1f1f66fe1db2bedf8dee3` | `tests/stub_supabase.sql` |
