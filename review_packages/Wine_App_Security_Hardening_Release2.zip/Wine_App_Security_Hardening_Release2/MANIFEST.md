# Manifest: Wine App privilege hardening, release 2 (2026-11-08)

- FINAL AND TESTED, NOT DEPLOYED. Deploy with DEPLOY.md (Supabase SQL editor) after the owner's approval.
- Commit on main: 49f9eb42107f13403ea23f2025f6c13f80f5a187; merged into vwm: 729f0f1bab93ed8fb34ca5acb32acbe51f9de99b. sql/ is byte-identical to that commit.
- results/: the last local Supabase run (352 passed, 0 failed); inventories are from local stand-ins, not production. No keys or tokens; synthetic users.

| SHA-256 | File |
|---|---|
| `1cdf99258f602573c7b07d4ec1ee4ca0c15992f26a5b67638756121b3a190d48` | `DEPLOY.md` |
| `13c710c0f5b71286a46620cf4ad38db071065e30f20970abb4a68cb3904b16d9` | `reports/ANON_ACCESS_AUDIT.md` |
| `813dd5fc02c3ca787637092691f02a84d487aa273365eb32f6aadf3b26757dd2` | `reports/ANON_HARDENING_CHANGE_REPORT.md` |
| `5e5251a36bcffe04b80a81d6d8b353628c37d100a39621d8065e7c64cdeb2af9` | `results/api_after.txt` |
| `88edb518d1b9064973f1b8a50331a223b59c1e4335b0c5577fcfc2ef3223fc43` | `results/api_before.txt` |
| `f3a69f17620bd5ec70a1638564a928d0c1ba536fc9e879273fbd0539626b4cd1` | `results/api_rolled.txt` |
| `49242161f43e153ae0bbfdf6b27a06a4c21a83b5ebb5e3eb18b07325e339fdbc` | `results/app_after.txt` |
| `e55a0f32e72f1223961287400f27fa5165701f9daa9e5cebfa65b2eab7e37ed9` | `results/app_before.txt` |
| `84016a660bea55a7956cb33f4989ad3a5154d8abbcfa2772741721ebb52efb90` | `results/app_rolled.txt` |
| `f61ee5518deb8629a0f714deba67dff25150409c33dba1a3bf8ee99ca100eab4` | `results/inventory_after.txt` |
| `c6858724ffcec1f7d53bff291c63e7078b56806d83496b8d224b937492432ad9` | `results/inventory_before.txt` |
| `5759b648a86c8a46f74aba07121740d9c1da12f40e24b4f811979f239e3b9dc2` | `results/inventory_before_vs_after.diff` |
| `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | `results/inventory_before_vs_rolled.diff` |
| `c6858724ffcec1f7d53bff291c63e7078b56806d83496b8d224b937492432ad9` | `results/inventory_final.txt` |
| `2cb33d580bccee381ce2040c5cbc0e113d8d68ff6f3c790a7215ab5fab372d4c` | `results/inventory_post_stop.txt` |
| `2cb33d580bccee381ce2040c5cbc0e113d8d68ff6f3c790a7215ab5fab372d4c` | `results/inventory_pre_stop.txt` |
| `f61ee5518deb8629a0f714deba67dff25150409c33dba1a3bf8ee99ca100eab4` | `results/inventory_reapplied.txt` |
| `c6858724ffcec1f7d53bff291c63e7078b56806d83496b8d224b937492432ad9` | `results/inventory_rolled.txt` |
| `c6858724ffcec1f7d53bff291c63e7078b56806d83496b8d224b937492432ad9` | `results/inventory_very_end.txt` |
| `a82285f3255af4aeec0846b64a2a575dcef940828b3cf1e14cb3e50d92e170c7` | `results/m001_verify.txt` |
| `009598c9b80ae627d5ad4f5f28b9be3203f1a0f50c4f58dcf25d06c2851ee455` | `results/rollback.txt` |
| `bff016bad114bd97cace5fae2f589361dc78ef7af279c9fcaca6cd19e8eeddcc` | `results/rollback2.txt` |
| `009598c9b80ae627d5ad4f5f28b9be3203f1a0f50c4f58dcf25d06c2851ee455` | `results/rollback_private.txt` |
| `14d39d343f86eda0e0a955ff9f35027d12256114309562dcc4f02750da4d09cb` | `results/run_anon_tests_output.txt` |
| `3eba8d1f92c9db94fd9d038cbd0a50ffb20b3c0441a2357f283bd17bc0b2040a` | `results/up1.txt` |
| `c23da8a39946ce268e4c8134ad93e47a0dfbad54265e1b4bbb5fb9b7fd2c9dbf` | `results/up2.txt` |
| `580e0aecf9ba40f4788407c8545d2b95179e7ef23cf96fbe503664f36db56b17` | `results/up3.txt` |
| `692b070c13508d9bec6235671449058fb3528fc431f5322c307b6f2ff692cfbb` | `results/up_guard.txt` |
| `da02138a7f1f5f9f0767d230fa5073f2483d3bf3826c81d0b8236b5b1e011572` | `results/up_preflight.txt` |
| `580e0aecf9ba40f4788407c8545d2b95179e7ef23cf96fbe503664f36db56b17` | `results/up_private.txt` |
| `a37c36f39ec0e50eb96fc196d6e64959b258c8cefb39a49821638107d6673033` | `results/verify_after.txt` |
| `13f286b305ba24c5c8566798911f33a642841fca4a0f3f1e014309da5b8d0685` | `results/verify_rolled.txt` |
| `58f101abc83d27f7dee12b27b389cc8b90d7deb471aef7b96d170c75a4bf2215` | `shared_staging_helpers/prereq_realistic.sql` |
| `862a01f375ff75b829802c8fcd2c3fe81634e649b74e8b8cfba6b80fd714de05` | `shared_staging_helpers/sb_lib.sh` |
| `3a8fe229a69a37243efa4376f6351e53c729277c57bc7f689ed71562b80a3ee3` | `sql/anon_hardening_rollback.sql` |
| `eddd95d7b76a8c3db619b25890b4fedbba4e3b55db7e8c32e00c0988eba2bb72` | `sql/anon_hardening_up.sql` |
| `18be15336d981d07c6f8e771d6b99e78d9300332c40c10c32b64dbee69100028` | `sql/anon_hardening_verify.sql` |
| `d99f96f0d8306b83fab82d1030711f7729930b8501c4e6b7a14fba6bdff2bc3b` | `sql/anon_inventory.sql` |
| `5caa56a39fd6847823828f9e8e1a734caf172ec252517c475473c766b6032aa8` | `tests/anon_api_tests.py` |
| `a40afd0a7724a9e92dd28739e3b079f01fe43f85f1b34e12e98c59fc461f6bcc` | `tests/app_code_tests.mjs` |
| `be5621a4d24d856ebbeb3c29d94a3c7b1a5b69cd01d9cf631a6214bf0422775a` | `tests/prereq_app.sql` |
| `6163f69dbdbb46f39e478d3da857937966193081eecc60d0a2d09f91325162c9` | `tests/run_anon_tests.sh` |
