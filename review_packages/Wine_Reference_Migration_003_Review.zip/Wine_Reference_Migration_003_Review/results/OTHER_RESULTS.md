# Other results (2026-11-08)

- Venue app (`vwm`) after the merge: the Migration 003 suite on the venue app passed 116/0. Venue checks: venue_ui 17/0, sure_ui 14/0,
  vrev_ui 48/0.
- Main app regression (fake database), all passed: Pairings 11, More/Food 25, Atlas 39, restaurant 29, card map 19, Morgon 13,
  Grand Cru 8, label names 7, steps 12; foods_check 49; restaurant_check 38.
- `live_post_deploy_003.mjs` against the local deployment: 17/0.
- Production, public key only, after publishing the new app code:
  - `live_smoke.mjs` 26/0;
  - `live_ui.mjs` 26/0 (main and /vwm/ against the production database);
  - `live_post_deploy_003.mjs`: "Migration 003 is not deployed yet", as expected.
- The `vwm` merge again left `rankaoc.js` imported twice in `owner.js`; the merge recipe's module-parse step caught it and it was fixed.
  The import order on main was then aligned with `vwm`, so later merges no longer double it.
