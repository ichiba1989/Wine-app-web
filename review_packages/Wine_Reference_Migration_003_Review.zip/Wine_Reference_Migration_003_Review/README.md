# Wine Reference: Migration 003 review package (2026-11-08)

Release `003 r1 (2026-11-08)`. **Implemented and tested locally; NOT run on production.** The app code is published: until 003 runs,
the Reference tab's new parts fall back to 002's behaviour or say "needs migration 003".

Start with `migration_003/README.md` (what you can do, the recommended types, the link rules), then `migration_003/DEPLOY_003.md`
(SQL Editor steps). The results are in `results/`; the app changes are in `app/`. `MANIFEST.txt` lists the SHA-256 of every file.

Repository `ichiba1989/Wine-app-web`:
- `main` at 942b29a;
- `vwm` at 09b6214.
