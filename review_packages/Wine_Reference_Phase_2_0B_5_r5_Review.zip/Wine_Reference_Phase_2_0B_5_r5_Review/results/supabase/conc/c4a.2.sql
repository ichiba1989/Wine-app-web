begin;
set local role authenticated; select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000c', true); select public.ref_review('entities', 'e0000000-0000-0000-0000-000000000001', 'retire');
commit;
