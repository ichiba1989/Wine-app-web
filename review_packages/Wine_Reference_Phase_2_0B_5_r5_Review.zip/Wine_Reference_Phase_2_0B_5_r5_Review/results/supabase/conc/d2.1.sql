begin;
select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000a', true); update wine_reference.claims set object_entity_id = object_entity_id where id = 'c0000000-0000-0000-0000-000000000009'; select pg_sleep(1); insert into wine_reference.claim_evidence (claim_version_id, source_version_id, modality, locator) values ('f0000000-0000-0000-0000-000000000009', '51000000-0000-0000-0000-000000000001', 'documentary', 'd2');
select pg_sleep(1.5);
commit;
