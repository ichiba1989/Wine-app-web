begin;
set local role authenticated; select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000a', true); select public.ref_review('claim_versions', 'f0000000-0000-0000-0000-000000000009', 'submit');
select pg_sleep(1.5);
commit;
