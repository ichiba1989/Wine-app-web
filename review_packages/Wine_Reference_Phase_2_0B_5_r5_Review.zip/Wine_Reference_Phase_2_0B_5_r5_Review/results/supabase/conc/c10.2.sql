begin;
set local role authenticated; select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000b', true); select public.ref_review('entity_names', 'a0000000-0000-0000-0000-000000000044', 'reject');
commit;
