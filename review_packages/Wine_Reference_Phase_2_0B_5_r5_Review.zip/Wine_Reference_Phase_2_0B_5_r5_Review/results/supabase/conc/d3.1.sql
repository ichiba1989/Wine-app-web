begin;
select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000a', true); insert into wine_reference.source_versions (source_id, version_label, rights_id, storage_path) values ('50000000-0000-0000-0000-000000000001', 'v3', 'b0000000-0000-0000-0000-000000000002', 'private/x.pdf'); select pg_sleep(1); insert into wine_reference.claim_evidence (claim_version_id, source_version_id, modality, locator) values ('f0000000-0000-0000-0000-000000000009', '51000000-0000-0000-0000-000000000001', 'documentary', 'd3');
select pg_sleep(1.5);
commit;
