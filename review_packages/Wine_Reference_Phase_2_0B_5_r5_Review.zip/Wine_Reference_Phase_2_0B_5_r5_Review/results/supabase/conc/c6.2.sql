begin;
select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000a', true); insert into wine_reference.claims (subject_entity_id, relationship_type, object_entity_id) values ('e0000000-0000-0000-0000-000000000004', 'part_of', 'e0000000-0000-0000-0000-000000000003');
commit;
