begin;
select set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-0000-0000-00000000000a', true); insert into wine_reference.claim_version_dependencies (dependent_version_id, depends_on_version_id) values ('f0000000-0000-0000-0000-000000000007', 'f0000000-0000-0000-0000-000000000008');
select pg_sleep(1.5);
commit;
