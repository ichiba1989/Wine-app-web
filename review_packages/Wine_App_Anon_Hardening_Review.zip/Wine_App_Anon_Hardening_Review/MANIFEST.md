# Manifest: Wine App anonymous-access hardening review package (Phase 2.0B.6)

- PROPOSAL ONLY: not run on the live database; no app file changed; Migration 001 r5 unchanged.
- Commit on main: 0720d3c6af8392014ca89c6fe0941029545b11a8; merged into vwm: 43b136197a5d1d9831f0c7e475c6f4ea5dcf2f87.
- sql/ is byte-identical to that commit. Open reports/ANON_HARDENING_CHANGE_REPORT.md first.
- results/: the last full local run (293 passed, 0 failed) and the privilege inventories before, after and after rollback (local stand-ins, not production). Scratch path replaced by <scratch>; no keys or tokens; test users are synthetic.

| SHA-256 | File |
|---|---|
| `13c710c0f5b71286a46620cf4ad38db071065e30f20970abb4a68cb3904b16d9` | `reports/ANON_ACCESS_AUDIT.md` |
| `31188a6e4504851784de24a736c0e74231221767967fa75382c24ba889833cb1` | `reports/ANON_HARDENING_CHANGE_REPORT.md` |
| `4892449db494a0cee6effcfc147155da3eb196c04287476112f91c7865eab192` | `results/api_after.txt` |
| `f35defd1c65c44c17d5960c5e80dcc7e1b79d2d14ddef6aa5597801956abb4b8` | `results/api_before.txt` |
| `9b121f71585af163894b69ff574583e9b6e6676cb8268f8a3fe236a7a41edaff` | `results/api_rolled.txt` |
| `49242161f43e153ae0bbfdf6b27a06a4c21a83b5ebb5e3eb18b07325e339fdbc` | `results/app_after.txt` |
| `e55a0f32e72f1223961287400f27fa5165701f9daa9e5cebfa65b2eab7e37ed9` | `results/app_before.txt` |
| `84016a660bea55a7956cb33f4989ad3a5154d8abbcfa2772741721ebb52efb90` | `results/app_rolled.txt` |
| `e4f5c9834af90f4551bad5dbc7dfcc48ba4ceb56fcfd587672aef8cb40cf1a38` | `results/inventory_after.txt` |
| `87b77c5467478ab0190bd000185bbbb27f7da5f3dfa51b6ae9af35e573d68221` | `results/inventory_before.txt` |
| `38449447ceb8bcb46009d75fc522602ed6ffcc955b40962fe50f7fd0e9452074` | `results/inventory_before_vs_after.diff` |
| `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | `results/inventory_before_vs_rolled.diff` |
| `87b77c5467478ab0190bd000185bbbb27f7da5f3dfa51b6ae9af35e573d68221` | `results/inventory_final.txt` |
| `b268864f1f98dae6ae8cc8a5444e84acce6671a1d15a36a45b0940a0d4aaed03` | `results/inventory_post_stop.txt` |
| `b268864f1f98dae6ae8cc8a5444e84acce6671a1d15a36a45b0940a0d4aaed03` | `results/inventory_pre_stop.txt` |
| `e4f5c9834af90f4551bad5dbc7dfcc48ba4ceb56fcfd587672aef8cb40cf1a38` | `results/inventory_reapplied.txt` |
| `87b77c5467478ab0190bd000185bbbb27f7da5f3dfa51b6ae9af35e573d68221` | `results/inventory_rolled.txt` |
| `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | `results/rollback.txt` |
| `bff016bad114bd97cace5fae2f589361dc78ef7af279c9fcaca6cd19e8eeddcc` | `results/rollback2.txt` |
| `f4dcfd7cfeb01840adf081ca39e0dfb96c23618a7d932b131139887f49c35ec5` | `results/run_anon_tests_output.txt` |
| `6aed551ba354ee7c7ef2bbb30306bb2ba33e0e1389288e7891803012c8ba1766` | `results/up1.txt` |
| `6146be2c74a453770f4b18a0e16a9e7e02895b9947cf7d04d50113fb32261e7e` | `results/up2.txt` |
| `d463ad4220456249a9863fee5a86da04e258c74b89f331799f5653a40228a7e3` | `results/up3.txt` |
| `f778dc63a0fc8c63745fb59e4f0efd34884d5829b463d10a4e73f2d3b5788bf0` | `results/up_guard.txt` |
| `86e61585124c044f6012d2166728be7af0a1a74b911da40f7f6df155d8adf017` | `results/up_preflight.txt` |
| `58f101abc83d27f7dee12b27b389cc8b90d7deb471aef7b96d170c75a4bf2215` | `shared_staging_helpers/prereq_realistic.sql` |
| `862a01f375ff75b829802c8fcd2c3fe81634e649b74e8b8cfba6b80fd714de05` | `shared_staging_helpers/sb_lib.sh` |
| `412eb056d64b12e5a2462b2264b1ef720195544de18a281168798f339bd59761` | `sql/anon_hardening_rollback.sql` |
| `b2f84af614f3a99563613eedb515d64ae0b675318ff41358c4df63a9b0224e37` | `sql/anon_hardening_up.sql` |
| `6100f8ca6e61c58cb303518bfa50e2b2eb8077ffe592789ccef67dd1789761e6` | `sql/anon_inventory.sql` |
| `796a6132ebe7b89425cfc4f056fab0e4f38d399a1fac48c2c656f3baed9245e1` | `tests/anon_api_tests.py` |
| `a40afd0a7724a9e92dd28739e3b079f01fe43f85f1b34e12e98c59fc461f6bcc` | `tests/app_code_tests.mjs` |
| `be5621a4d24d856ebbeb3c29d94a3c7b1a5b69cd01d9cf631a6214bf0422775a` | `tests/prereq_app.sql` |
| `611fc054947adbbfd68512ab884fe46483d4a883c7e39d08e51db0607f384e08` | `tests/run_anon_tests.sh` |
