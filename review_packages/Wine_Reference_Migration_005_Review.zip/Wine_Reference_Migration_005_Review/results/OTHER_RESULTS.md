# Other results (2026-11-13)

- `run005.txt`: the 005 suite on main. 85/0.
- `run005v.txt`: the 005 suite on the venue app. 85/0.
- `run004r.txt`: 004's suite against the new app, before 005. 78/0.
- Venue checks: 17/0, 14/0, 48/0. Main app regression (fake database): all passed.
- `live_post_deploy_005.mjs` against the local deployment: 25/0.
- Production, public key, after publishing the new code (production has 002; 003 and 004 approved but not yet run):
  - `live_smoke.mjs` 26/0;
  - `live_ui.mjs` 26/0;
  - `live_post_deploy_003`/`004`/`005`: "not deployed yet".
