# Wine Reference: Migration 005 review package (2026-11-13)

Release `005 r1 (2026-11-13)`: the grape-rule reconciliation and import workflow. **Implemented and tested locally; NOT run on
production.** It needs 003 and 004 first.

Start with `migration_005/README.md`, then `migration_005/DEPLOY_005.md`. `MANIFEST.txt` lists the SHA-256 of every file.

Repository: `main` at 084b46d, `vwm` at 523e345.
